const observableModule = require("tns-core-modules/data/observable");
const ObservableArray = require("tns-core-modules/data/observable-array").ObservableArray;
const settings = require("application-settings");

function MainPageViewModel() {
    const viewModel = observableModule.fromObject({
            spellTypes: new ObservableArray(),
            spells: [],
            characterInfo: [
            { infoTitle: "Personality Traits", info: settings.getString("Personality Traits", "") },
            { infoTitle: "Ideals", info: settings.getString("Ideals", "") },
            { infoTitle: "Bonds", info: settings.getString("Bonds", "") },
            { infoTitle: "Flaws", info: settings.getString("Flaws", "") },
            { infoTitle: "Features and Traits", info: settings.getString("Features and Traits", "") },
            { infoTitle: "Other Proficiencies and Languages", info: settings.getString("Other Proficiences and Languages", "") },
            { infoTitle: "Allies and Organizations", info: settings.getString("Allies and Organizations", "") },
        ]
    });
    return viewModel;
}

module.exports = MainPageViewModel;
