const SettingsViewModel = require("./settings-view-model");
const modalViewModule = "home/modal-view-page";
var settings = require("application-settings");

function onNavigatingTo(args) {
    const page = args.object;
    page.bindingContext = {};
}

function navigate(args) {

}

function onSelectedIndexChanged(args) {

}

exports.onNavigatingTo = onNavigatingTo;
exports.navigate = navigate;
exports.onSelectedIndexChanged = onSelectedIndexChanged;