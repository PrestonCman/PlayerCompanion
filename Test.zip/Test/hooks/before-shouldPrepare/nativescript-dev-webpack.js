module.exports = require("nativescript-dev-webpack/lib/before-shouldPrepare.js");
