const SettingsViewModel = require("./settings-view-model");
const observableModule = require("tns-core-modules/data/observable");
var settings = require("tns-core-modules/application-settings");



function onNavigatingTo(args) {
    const page =args.object;
    page.bindingContext = new SettingsViewModel();
    if(!settings.getString("stats"+settings.getNumber("selected").toString())) {
        console.log("Hi");
        settings.setString("stats"+settings.getNumber("selected").toString(), 
    '{"prof":"2", "str":"10", "dex":"10", "con":"10", "int":"10", "wis":"10", "chr":"10", "spd":"30","maxHp":"8", "hp":"8", "ac":"15"}')
    }
    var s = settings.getString("stats"+settings.getNumber("selected").toString());
    var obj = JSON.parse(s);
    page.bindingContext.stats.push({prof:obj.prof, str:obj.str, dex:obj.dex,
        con:obj.con,int:obj.int,wis:obj.wis,chr:obj.chr,
        spd:obj.spd, maxHp: obj.maxHp, hp:obj.hp, ac:obj.ac});
}

function navigate(args) {
    const page = args.object;
    page.frame.navigate(page.text);
}
function changedTab(args) {

}
function edit(args) {
    
}

exports.edit = edit;
exports.onNavigatingTo = onNavigatingTo;
exports.navigate = navigate;
exports.changedTab = changedTab;