const MainPageViewModel = require("./main-page-view-model");
const observableModule = require("tns-core-modules/data/observable");
var settings = require("tns-core-modules/application-settings");
const modalViewModule = "main/spell-modal-view";
const Label = require("tns-core-modules/ui/label").Label;
var page;
var s;
var obj;
var loaded = [];

function onNavigatingTo(args) {
    page = args.object;
    page.getViewById("TabView").selectedIndex = settings.getNumber("tab");
    for (var i = 0; i < 10; i++) loaded[i] = false;
    page.bindingContext = new MainPageViewModel();
    page.bindingContext.spellTypes = [];
    for (var i = 0; i < 10; i++)
    {
        const spellType = observableModule.fromObject({
            level: i,
            slotsTotal : 0,
            slotsExpended : 0,
            spells: []
        });
        if (spellType.level == 0) 
        {
            spellType.slotsTotal = "";
            spellType.slotsExpended = "Cantrips";
        }
        page.bindingContext.spellTypes.push(spellType);
    }
    if(!settings.getNumber("spellCount"+settings.getNumber("selected").toString())){
        settings.setNumber("spellCount"+settings.getNumber("selected").toString(),0);
    }
    for(var i = 0; i < settings.getNumber("spellCount"+settings.getNumber("selected").toString()); i++)
    {
        s = settings.getString("spell"+settings.getNumber("selected").toString()+i)
        obj = JSON.parse(s);
        page.bindingContext.spellTypes[obj.level].spells.push({spell:obj.name});
    }

    page.bindingContext.characterInfo = [];
    for (var i = 0; i < page.bindingContext.misc.length; i++)
    {
        const info = observableModule.fromObject({
            infoTitle: page.bindingContext.misc[i].infoTitle,
            info: page.bindingContext.misc[i].info
        });

        console.log(page.bindingContext.misc[i].info);
        console.log(page.bindingContext.misc[i].infoTitle);
        page.bindingContext.characterInfo.push(info);
    }

    

    for (var i = 0; i < page.bindingContext.characterInfo.length; i++)
    {
        page.bindingContext.characterInfo[i].on(observableModule.Observable.propertyChangeEvent,
            (data) => {
                if( data.propertyName == "info" ) {
                    settings.setString(data.object.infoTitle+settings.getNumber("selected").toString(), data.value);
                }
        });
    }
}

exports.loadSpells = function (args) {
    const stack = args.object;
    const page = stack.page;
    if (loaded[stack.id] == false)
    {
        const spellType = page.bindingContext.spellTypes[stack.id];
        for (var i = 0; i < spellType.spells.length; i++)
        {
            const spell = new Label();
            spell.text = spellType.spells[i].spell;
            stack.addChild(spell);
        }
        loaded[stack.id] = true;
    }
}

exports.deleteSpell=function(args){
    settings.setNumber("tab", 4);
    var navigation ={
        moduleName:"main/delete-spell",
        spells:page.bindingContext.spells
    }
    page.frame.navigate(navigation);
}

function viewSpells(args) {
    const list = args.object;
    const page = list.page;
    const spells = page.getViewById(args.index);
    spells.visibility = spells.visibility == "collapse" ? "visible" : "collapse";
}

function addSpell(args) {
    const mainView = args.object;
    const page = mainView.page;
    const context = { level:"", name:""};
    const fullscreen = false;
    settings.setNumber("tab", 4);
    mainView.showModal(modalViewModule, context, (level, name) => {
        page.frame.navigate("main/main-page");
    }, fullscreen);

}

exports.goBack = function (args) {
    for (var i = 0; i < page.bindingContext.characterInfo.length; i++)
    page.bindingContext.characterInfo[i].off(observableModule.Observable.propertyChangeEvent);
    page.frame.navigate("home/home-page");
}

exports.viewSpells = viewSpells;
exports.addSpell = addSpell;
exports.onNavigatingTo = onNavigatingTo;
