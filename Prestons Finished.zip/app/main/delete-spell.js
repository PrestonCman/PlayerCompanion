const MainPageViewModel = require("./main-page-view-model");
var settings = require("tns-core-modules/application-settings");
var page;

exports.onNavigatingTo=function(args) {
    page = args.object;
    page.bindingContext = new MainPageViewModel();

    for(var i = 0; i < settings.getNumber("spellCount"); i++)
    {   
        s = settings.getString("spell"+i);
        obj = JSON.parse(s);
        page.bindingContext.spells.push({level:obj.level, name:obj.name});
    }
}

exports.deleteSpell=function(args)
{
    var index = args.index;
    var spells = settings.getNumber("spellCount")-1;
    if(index == spells)
    {
        settings.remove('spell'+index)
        settings.setNumber("spellCount", spells);
    }
    else
    {
        settings.setString('spell'+index, settings.getString('spell'+spells));
        settings.remove('spell'+spells);
        settings.setNumber("spellCount", spells);
    }
    page.frame.navigate("main/main-page");
}


function onCancelButtonTap(args){
    page.frame.navigate("main/main-page");
}

exports.onCancelButtonTap = onCancelButtonTap;