const SettingsViewModel = require("./settings-view-model");
const observableModule = require("tns-core-modules/data/observable");
var settings = require("application-settings");
const modalViewModule = "home/modal-view-page";
const weaponViewModule = "main/weapon-view-page";
const spellViewModule = "main/spell-modal-view";
const itemViewModule = "main/item-modal-view";
var page;
var loaded = [];
const Label = require("tns-core-modules/ui/label").Label;
var s;
var obj;
var types = ["Miscellaneous","Consumables","Adventuring Gear","Wondrous Items","Weapons","Armor","Tools"
,"Containers","Ammunition"];
function onNavigatingTo(args) {
    page = args.object;
    page.bindingContext = new SettingsViewModel();
    s = settings.getString("character"+settings.getNumber("selected").toString());
    obj = JSON.parse(s);
    page.getViewById("actionTitle").text =  obj.name;
    page.getViewById("TabView").selectedIndex = settings.getNumber("tab");
    if(!settings.getNumber("numWeapons"+settings.getNumber("selected").toString())){
        settings.setNumber("numWeapons"+settings.getNumber("selected").toString(),0);
    }
    for(var i = 0; i < settings.getNumber("numWeapons"+settings.getNumber("selected").toString()); i++)
    {   
        s = settings.getString("weapon"+settings.getNumber("selected").toString()+i)
        obj = JSON.parse(s);
        page.bindingContext.weapons.push({weapon:obj.weapon, atkBonus:obj.atkBonus, dmg: obj.dmg});
    }

    if(!settings.getString("stats"+settings.getNumber("selected").toString())) {
        settings.setString("stats"+settings.getNumber("selected").toString(), 
    '{"prof":"2","str":"10","dex":"10","con":"10","int":"10","wis":"10","chr":"10","spd":"30","maxHp":"8","hp":"8","ac":"15"}')
    }
    s = settings.getString("stats"+settings.getNumber("selected").toString());
    obj = JSON.parse(s);
    
    page.bindingContext.stats = {
        prof:obj.prof,
        str:obj.str,
        dex:obj.dex,
        con:obj.con,
        int:obj.int,
        wis:obj.wis,
        chr:obj.chr,
        spd:obj.spd,
        maxHp:obj.maxHp,
        hp:obj.hp,
        ac:obj.ac,
        strMod:Math.floor((obj.str-10)/2),
        dexMod:Math.floor((obj.dex-10)/2),
        conMod:Math.floor((obj.con-10)/2),
        intMod:Math.floor((obj.int-10)/2),
        wisMod:Math.floor((obj.wis-10)/2),
        chrMod:Math.floor((obj.chr-10)/2)
        };
   // console.log(wisMod);
    for (var i = 0; i < 9; i++) loaded[i] = false;
        page.bindingContext.itemTypes = [];
    for (var i = 0; i < 9; i++)
    {
        const itemType = observableModule.fromObject({
            type: i,
            typeName: types[i],
            items: []
        });
        
        page.bindingContext.itemTypes.push(itemType);
    }
    if(!settings.getNumber("itemCount")){
        settings.setNumber("itemCount", 0);
    }

    for(var i = 0; i < settings.getNumber("itemCount"); i++)
    {
        s = settings.getString("item"+i)
        obj = JSON.parse(s);
        page.bindingContext.itemTypes[obj.type].items.push({name:obj.name});
    }

    for (var i = 0; i < 10; i++) loaded[i] = false;
    page.bindingContext.spellTypes = [];
    for (var i = 0; i < 10; i++)
    {
        const spellType = observableModule.fromObject({
            level: i,
            slotsTotal : 0,
            slotsExpended : 0,
            spells: []
        });
        if (spellType.level == 0) 
        {
            spellType.slotsTotal = "";
            spellType.slotsExpended = "Cantrips";
        }
        page.bindingContext.spellTypes.push(spellType);
    }
    if(!settings.getNumber("spellCount")){
        settings.setNumber("spellCount",0);
    }
    for(var i = 0; i < settings.getNumber("spellCount"); i++)
    {
        s = settings.getString("spell"+i)
        obj = JSON.parse(s);
        page.bindingContext.spellTypes[obj.level].spells.push({spell:obj.name});
    }

    page.bindingContext.on(observableModule.Observable.propertyChangeEvent,
        (data) => {
            if( data.propertyName == "info" ) {
                console.log("Hi");
                settings.setString(data.object.id, data.value);
            }
        });
}

exports.onSelectedIndexChanged = function(args) {
    page = args.object.page;
    if (args.newIndex == 0)
    {
        page.getViewById("actionTitle").text = "Inventory";
    }
    else if(args.newIndex == 1){
        page.getViewById("actionTitle").text = "Character Information";
    }
    else if(args.newIndex == 2){
        s = settings.getString("character"+settings.getNumber("selected").toString());
        obj = JSON.parse(s);
        page.getViewById("actionTitle").text =  obj.name;
    }
    else if(args.newIndex == 3){
        page.getViewById("actionTitle").text = "Combat";
    }
    else if(args.newIndex == 4){
        page.getViewById("actionTitle").text = "Spells";
    }
}

function onLoaded(args) {
    const tabView = args.object;
    const vm = new observableModule.Observable();
    vm.set("tabSelectedIndex", 0);

    tabView.bindingContext = vm;
}

function openModal(args) {
    const button = args.object;
    const page = button.page;
    const mainView = args.object;
    const context = { charName:"", race:"", charClass:""};
    const fullscreen = false;
    mainView.showModal(modalViewModule, context, (charName, race, charClass) => {
        page.frame.navigate("main/main-page");
    }, fullscreen);

}

exports.openWeapon = function(args){
    const button = args.object;
    const page = button.page
    const mainView = args.object;
    const context = {weapon:"", atkBonus:"", dmg:""};
    const fullscreen = false;
    settings.setNumber("tab", 3);
    mainView.showModal(weaponViewModule, context, (weapon, atkBonus, dmg)=>{
        //console.log(weapon + " , " + atkBonus + " , " + dmg);
        page.frame.navigate("main/main-page");
    }, fullscreen);
}
exports.openWeaponDelete = function(args){
    settings.setNumber("tab", 3);
    var navigation ={
        moduleName:"main/delete-weapon",
        weapons:page.bindingContext.weapons
    }
    page.frame.navigate(navigation);
}

exports.editInfo = function(args) {
    var navigation = {
        moduleName:"main/edit-page",
        context: {prof:page.bindingContext.stats.prof, str:page.bindingContext.stats.str, 
            dex:page.bindingContext.stats.dex, con:page.bindingContext.stats.con, 
            int:page.bindingContext.stats.int, wis:page.bindingContext.stats.wis,
            chr:page.bindingContext.stats.chr, spd:page.bindingContext.stats.spd,
            hp:page.bindingContext.stats.hp, ac:page.bindingContext.stats.ac,
            strMod:page.bindingContext.stats.strMod, dexMod:page.bindingContext.stats.dexMod,
            conMod:page.bindingContext.stats.conMod, intMod:page.bindingContext.stats.conMod,
            wisMod:page.bindingContext.stats.wisMod, chrMod:page.bindingContext.stats.chrMod}
        }
        console.log(navigation.context);
        
    
    page.frame.navigate(navigation);
}

exports.loadSpells = function (args) {
    const stack = args.object;
    const page = stack.page;
    if (loaded[stack.id] == false)
    {
        const spellType = page.bindingContext.spellTypes[stack.id];
        for (var i = 0; i < spellType.spells.length; i++)
        {
            const spell = new Label();
            spell.text = spellType.spells[i].spell;
            stack.addChild(spell);
        }
        loaded[stack.id] = true;
    }
}

exports.deleteSpell=function(args){
    settings.setNumber("tab", 4);
    var navigation ={
        moduleName:"main/delete-spell",
        spells:page.bindingContext.spells
    }
    page.frame.navigate(navigation);
}

function viewSpells(args) {
    const list = args.object;
    const page = list.page;
    const spells = page.getViewById(args.index);
    spells.visibility = spells.visibility == "collapse" ? "visible" : "collapse";
}

function addSpell(args) {
    const mainView = args.object;
    const page = mainView.page;
    const context = { level:"", name:""};
    const fullscreen = false;
    settings.setNumber("tab", 4);
    mainView.showModal(spellViewModule, context, (level, name) => {
        page.frame.navigate("main/main-page");
    }, fullscreen);
}

exports.loadItems = function (args) {
    const stack = args.object;
    const page = stack.page;
    if (loaded[stack.id] == false)
    {
        const itemType = page.bindingContext.itemTypes[stack.id];
        for (var i = 0; i < itemType.items.length; i++)
        {
            const item = new Label();
            item.text = itemType.items[i].name;
            stack.addChild(item);
        }
        loaded[stack.id] = true;
    }
}

exports.deleteItem=function(args){
    settings.setNumber("tab", 0);
    var navigation ={
        moduleName:"main/delete-item",
        items:page.bindingContext.items
    }
    page.frame.navigate(navigation);
}

exports.viewItems=function(args) {
    const list = args.object;
    const page = list.page;
    const items = page.getViewById(args.index);
    items.visibility = items.visibility == "collapse" ? "visible" : "collapse";
}

exports.addItem=function(args) {
    const mainView = args.object;
    const page = mainView.page;
    const context = { type:"", name:""};
    const fullscreen = false;
    settings.setNumber("tab", 0);
    mainView.showModal(itemViewModule, context, (type, name) => {
        page.frame.navigate("main/main-page");
    }, fullscreen);
}

exports.goBack = function(args)
{
    page.frame.navigate("home/home-page")
}

exports.viewSpells = viewSpells;
exports.addSpell = addSpell;
exports.onLoaded = onLoaded;
exports.openModal = openModal;
exports.onNavigatingTo = onNavigatingTo;