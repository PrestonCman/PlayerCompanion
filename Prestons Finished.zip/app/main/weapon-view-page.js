var settings = require("application-settings");
const observableModule = require("tns-core-modules/data/observable");
let closeCallback;

function onShownModally(args) {
    const context = args.context;
    closeCallback = args.closeCallback;
    const page = args.object;
    page.bindingContext = observableModule.fromObject(context);
}
exports.onShownModally = onShownModally;

function onAddWeaponTap(args) {
    var button = args.object;
    var page = button.page;
    var index = settings.getNumber("numWeapons"+settings.getNumber("selected").toString()).toString();
    var obj = {'weapon':page.bindingContext.get("weapon"),
               'atkBonus':page.bindingContext.get("atkBonus"),
               'dmg':page.bindingContext.get("dmg")}
    
    var s = JSON.stringify(obj);
    settings.setString("weapon"+settings.getNumber("selected").toString()+index, s);

    const weapon = page.bindingContext.get("weapon");
    const atkBonus = page.bindingContext.get("atkBonus");
    const dmg = page.bindingContext.get("dmg");
    settings.setNumber("numWeapons"+settings.getNumber("selected").toString(), Number(index)+1);
    
    closeCallback(weapon, atkBonus, dmg);
}

function onCancelWeaponTap(args){
    args.object.closeModal();
}
exports.onAddWeaponTap = onAddWeaponTap;
exports.onCancelWeaponTap = onCancelWeaponTap;