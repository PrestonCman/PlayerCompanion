const SettingsPageViewModel = require("./settings-view-model");
var settings = require("tns-core-modules/application-settings");
var page;

exports.onNavigatingTo=function(args) {
    page = args.object;
    page.bindingContext = new SettingsPageViewModel();

    for(var i = 0; i < settings.getNumber("itemCount"); i++)
    {   
        s = settings.getString("item"+i);
        obj = JSON.parse(s);
        page.bindingContext.items.push({type:obj.type, name:obj.name});
    }
}

exports.deleteSpell=function(args)
{
    var index = args.index;
    var items = settings.getNumber("itemCount")-1;
    if(index == items)
    {
        settings.remove('item'+index)
        settings.setNumber("itemCount", items);
    }
    else
    {
        settings.setString('item'+index, settings.getString('item'+items));
        settings.remove('item'+items);
        settings.setNumber("itemCount", items);
    }
    page.frame.navigate("main/main-page");
}


exports.onCancelButtonTap = function(args){
    page.frame.navigate("main/main-page");
}

