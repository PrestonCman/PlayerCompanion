const settings = require("application-settings");
const SettingsViewModel = require("./settings-view-model");

var page;

exports.onNavigatingTo=function(args) {
    page = args.object;
    page.bindingContext = new SettingsViewModel();
    if(!settings.getNumber("numWeapons"+settings.getNumber("selected").toString())){
        settings.setNumber("numWeapons"+settings.getNumber("selected").toString(),0);
    }
    for(var i = 0; i < settings.getNumber("numWeapons"+settings.getNumber("selected")); i++)
    { 
        s = settings.getString("weapon"+settings.getNumber("selected").toString()+i)
        obj = JSON.parse(s);
        page.bindingContext.weapons.push({weapon:obj.weapon, atkBonus:obj.atkBonus, dmg: obj.dmg});
        
    }
}

exports.deleteWeapon=function(args)
{
    var index = args.index;
    var attacks = settings.getNumber("numWeapons"+settings.getNumber("selected").toString())-1;
    if(index == attacks)
    {
        settings.remove('weapon'+index)
        settings.setNumber("numWeapons"+settings.getNumber("selected").toString(), attacks);
    }
    else
    {
        settings.setString('weapon'+index, settings.getString('weapon'+attacks));
        settings.remove('weapon'+attacks);
        settings.setNumber("numWeapons"+settings.getNumber("selected").toString(), attacks);
    }
    page.frame.navigate("main/main-page");
}


function onCancelButtonTap(args){
    page.frame.navigate("main/main-page");
}

exports.onCancelButtonTap = onCancelButtonTap;