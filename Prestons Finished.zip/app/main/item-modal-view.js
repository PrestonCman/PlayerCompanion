var settings = require("application-settings");
const observableModule = require("tns-core-modules/data/observable");
let closeCallback;

exports.onShownModally = function(args) {
    const context = args.context;
    closeCallback = args.closeCallback;
    const page = args.object;
    page.bindingContext = observableModule.fromObject(context);
}

exports.onAddItemTap = function(args) {
    var button = args.object;
    page = button.page;
    var index = settings.getNumber("itemCount").toString();
    var obj = { type: page.bindingContext.type,
               name: page.bindingContext.name}
    
    var s = JSON.stringify(obj);
    settings.setString("item"+index, s);

    const type = page.bindingContext.get("type");
    const name = page.bindingContext.get("name");
    settings.setNumber("itemCount", Number(index)+1);
    console.log(s);
    closeCallback(type, name);
}

exports.onCancelItemTap = function(args){
    args.object.closeModal();
}
