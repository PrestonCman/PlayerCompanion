const settings = require("application-settings");
const SettingsViewModel = require("./settings-view-model");
const observableModule = require("tns-core-modules/data/observable");

exports.onNavigatingTo =function (args) {
    page = args.object;
    page.bindingContext = new SettingsViewModel();
    const context = args.context;
    page.bindingContext = observableModule.fromObject(context);
}

exports.update = function(args) {
    var textField = args.object;
    var page = textField.page;
    var obj = {'prof':page.bindingContext.get("prof"),
    'str':page.bindingContext.get("str"),
    'dex':page.bindingContext.get("dex"),
    'con':page.bindingContext.get("con"),
    'int':page.bindingContext.get("int"),
    'wis':page.bindingContext.get("wis"),
    'chr':page.bindingContext.get("chr"),
    'ac':page.bindingContext.get("ac"),
    'hp':page.bindingContext.get("hp"),
    'spd':page.bindingContext.get("spd"),
    'strMod':page.bindingContext.get("strMod"),
    'dexMod':page.bindingContext.get("dexMod"),
    'conMod':page.bindingContext.get("conMod"),
    'intMod':page.bindingContext.get("intMod"),
    'wisMod':page.bindingContext.get("wisMod"),
    'chrMod':page.bindingContext.get("chrMod")
    }
    var s = JSON.stringify(obj);
    settings.setString("stats"+settings.getNumber("selected").toString(), s);
  
    
    page.frame.navigate("main/main-page");
}

exports.goBack = function(args)
{
    page.frame.navigate("main/main-page")
}
