const observableModule = require("tns-core-modules/data/observable");
const settings = require("application-settings");

function SettingsViewModel() {
    const viewModel = observableModule.fromObject({
        
        numPlayers:0,
        numWeapons:0,
        
        characters: [

        ],
        weapons:[

        ],
        stats: [
            
        ]
        
    });
    return viewModel;
}

module.exports = SettingsViewModel;
