var settings = require("application-settings");
const observableModule = require("tns-core-modules/data/observable");
let closeCallback;

function onShownModally(args) {
    const context = args.context;
    closeCallback = args.closeCallback;
    const page = args.object;
    page.bindingContext = observableModule.fromObject(context);
}
exports.onShownModally = onShownModally;

function onAddButtonTap(args) {
    var button = args.object;
    page = button.page;
    var index = settings.getNumber("spellCount"+settings.getNumber("selected").toString()).toString();
    var obj = { level: page.bindingContext.level,
               name: page.bindingContext.name}
    
    var s = JSON.stringify(obj);
    settings.setString("spell"+settings.getNumber("selected").toString()+index, s);

    const level = page.bindingContext.get("level");
    const name = page.bindingContext.get("name");
    settings.setNumber("spellCount"+settings.getNumber("selected").toString(), Number(index)+1);
    
    closeCallback(level, name);
}

function onCancelButtonTap(args){
    args.object.closeModal();
}
exports.onAddButtonTap = onAddButtonTap;
exports.onCancelButtonTap = onCancelButtonTap;