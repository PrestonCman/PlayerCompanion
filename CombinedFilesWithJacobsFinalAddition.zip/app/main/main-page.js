const SettingsViewModel = require("./settings-view-model");
const observableModule = require("tns-core-modules/data/observable");
var settings = require("application-settings");
const modalViewModule = "home/modal-view-page";
const weaponViewModule = "main/weapon-view-page";
const spellViewModule = "main/spell-modal-view";
var page;
var loaded = [];
const Label = require("tns-core-modules/ui/label").Label;
var s;
var obj;

function onNavigatingTo(args) {
    page = args.object;
    page.bindingContext = new SettingsViewModel();
    s = settings.getString("character"+settings.getNumber("selected").toString());
    obj = JSON.parse(s);
    page.getViewById("actionTitle").text =  obj.name;
    page.getViewById("TabView").selectedIndex = settings.getNumber("tab");
    if(!settings.getNumber("numWeapons"+settings.getNumber("selected").toString())){
        settings.setNumber("numWeapons"+settings.getNumber("selected").toString(),0);
    }
    for(var i = 0; i < settings.getNumber("numWeapons"+settings.getNumber("selected").toString()); i++)
    {   
        s = settings.getString("weapon"+settings.getNumber("selected").toString()+i)
        obj = JSON.parse(s);
        page.bindingContext.weapons.push({weapon:obj.weapon, atkBonus:obj.atkBonus, dmg: obj.dmg});
    }

    if(!settings.getString("stats"+settings.getNumber("selected").toString())) {
        console.log("Hi");
        settings.setString("stats"+settings.getNumber("selected").toString(), 
    '{"prof":"2", "str":"10", "dex":"10", "con":"10", "int":"10", "wis":"10", "chr":"10", "spd":"30","maxHp":"8", "hp":"8", "ac":"15"}')
    }
    s = settings.getString("stats"+settings.getNumber("selected").toString());
    obj = JSON.parse(s);
    page.bindingContext.stats.push({prof:obj.prof, str:obj.str, dex:obj.dex,
        con:obj.con,int:obj.int,wis:obj.wis,chr:obj.chr,
        spd:obj.spd, maxHp: obj.maxHp, hp:obj.hp, ac:obj.ac});

    for (var i = 0; i < 10; i++) loaded[i] = false;
page.bindingContext.spellTypes = [];
    for (var i = 0; i < 10; i++)
    {
        const spellType = observableModule.fromObject({
            level: i,
            slotsTotal : 0,
            slotsExpended : 0,
            spells: []
        });
        if (spellType.level == 0) 
        {
            spellType.slotsTotal = "";
            spellType.slotsExpended = "Cantrips";
        }
        page.bindingContext.spellTypes.push(spellType);
    }
    if(!settings.getNumber("spellCount"+settings.getNumber("selected").toString())){
        settings.setNumber("spellCount"+settings.getNumber("selected").toString(),0);
    }
    for(var i = 0; i < settings.getNumber("spellCount"+settings.getNumber("selected").toString()); i++)
    {
        s = settings.getString("spell"+settings.getNumber("selected").toString()+i)
        obj = JSON.parse(s);
        page.bindingContext.spellTypes[obj.level].spells.push({spell:obj.name});
    }

    page.bindingContext.characterInfo = [];
    for (var i = 0; i < page.bindingContext.misc.length; i++)
    {
        const info = observableModule.fromObject({
            infoTitle: page.bindingContext.misc[i].infoTitle,
            info: page.bindingContext.misc[i].info
        });

        console.log(page.bindingContext.misc[i].info);
        console.log(page.bindingContext.misc[i].infoTitle);
        page.bindingContext.characterInfo.push(info);
    }

    

    for (var i = 0; i < page.bindingContext.characterInfo.length; i++)
    {
        page.bindingContext.characterInfo[i].on(observableModule.Observable.propertyChangeEvent,
            (data) => {
                if( data.propertyName == "info" ) {
                    settings.setString(data.object.infoTitle+settings.getNumber("selected").toString(), data.value);
                }
        });
    }
}

exports.onSelectedIndexChanged = function(args) {
    page = args.object.page;
    if (args.newIndex == 0)
    {
        page.getViewById("actionTitle").text = "Inventory";
    }
    else if(args.newIndex == 1){
        page.getViewById("actionTitle").text = "Character Information";
    }
    else if(args.newIndex == 2){
        s = settings.getString("character"+settings.getNumber("selected").toString());
        obj = JSON.parse(s);
        page.getViewById("actionTitle").text =  obj.name;
    }
    else if(args.newIndex == 3){
        page.getViewById("actionTitle").text = "Combat";
    }
    else if(args.newIndex == 4){
        page.getViewById("actionTitle").text = "Spells";
    }
}

function onLoaded(args) {
    const tabView = args.object;
    const vm = new observableModule.Observable();
    vm.set("tabSelectedIndex", 0);

    tabView.bindingContext = vm;
}

function openModal(args) {
    const button = args.object;
    const page = button.page;
    const mainView = args.object;
    const context = { charName:"", race:"", charClass:""};
    const fullscreen = false;
    mainView.showModal(modalViewModule, context, (charName, race, charClass) => {
        page.frame.navigate("main/main-page");
    }, fullscreen);

}

exports.openWeapon = function(args){
    const button = args.object;
    const page = button.page
    const mainView = args.object;
    const context = {weapon:"", atkBonus:"", dmg:""};
    const fullscreen = false;
    settings.setNumber("tab", 3);
    mainView.showModal(weaponViewModule, context, (weapon, atkBonus, dmg)=>{
        //console.log(weapon + " , " + atkBonus + " , " + dmg);
        page.frame.navigate("main/main-page");
    }, fullscreen);
}
exports.openWeaponDelete = function(args){
    settings.setNumber("tab", 3);
    var navigation ={
        moduleName:"main/delete-weapon",
        weapons:page.bindingContext.weapons
    }
    page.frame.navigate(navigation);
}

exports.edit = function(args) {
    
}

exports.loadSpells = function (args) {
    const stack = args.object;
    const page = stack.page;
    if (loaded[stack.id] == false)
    {
        const spellType = page.bindingContext.spellTypes[stack.id];
        for (var i = 0; i < spellType.spells.length; i++)
        {
            const spell = new Label();
            spell.text = spellType.spells[i].spell;
            stack.addChild(spell);
        }
        loaded[stack.id] = true;
    }
}

exports.deleteSpell=function(args){
    settings.setNumber("tab", 4);
    var navigation ={
        moduleName:"main/delete-spell",
        spells:page.bindingContext.spells
    }
    page.frame.navigate(navigation);
}

function viewSpells(args) {
    const list = args.object;
    const page = list.page;
    const spells = page.getViewById(args.index);
    spells.visibility = spells.visibility == "collapse" ? "visible" : "collapse";
}

function addSpell(args) {
    const mainView = args.object;
    const page = mainView.page;
    const context = { level:"", name:""};
    const fullscreen = false;
    settings.setNumber("tab", 4);
    mainView.showModal(spellViewModule, context, (level, name) => {
        page.frame.navigate("main/main-page");
    }, fullscreen);
}

exports.goBack = function(args)
{
    page.frame.navigate("home/home-page")
}

exports.viewSpells = viewSpells;
exports.addSpell = addSpell;
exports.onLoaded = onLoaded;
exports.openModal = openModal;
exports.onNavigatingTo = onNavigatingTo;