const MainPageViewModel = require("./main-page-view-model");
var settings = require("tns-core-modules/application-settings");
var page;

exports.onNavigatingTo=function(args) {
    page = args.object;
    page.bindingContext = new MainPageViewModel();

    for(var i = 0; i < settings.getNumber("spellCount"+settings.getNumber("selected").toString()); i++)
    {   
        s = settings.getString("spell"+settings.getNumber("selected").toString()+i);
        obj = JSON.parse(s);
        page.bindingContext.spells.push({level:obj.level, name:obj.name});
    }
}

exports.deleteSpell=function(args)
{
    var index = args.index;
    var spells = settings.getNumber("spellCount"+settings.getNumber("selected").toString())-1;
    if(index == spells)
    {
        settings.remove('spell'+settings.getNumber("selected").toString()+index)
        settings.setNumber("spellCount"+settings.getNumber("selected").toString(), spells);
    }
    else
    {
        settings.setString('spell'+settings.getNumber("selected").toString()+index, settings.getString('spell'+settings.getNumber("selected").toString()+spells));
        settings.remove('spell'+settings.getNumber("selected").toString()+spells);
        settings.setNumber("spellCount"+settings.getNumber("selected").toString(), spells);
    }
    page.frame.navigate("main/main-page");
}


function onCancelButtonTap(args){
    page.frame.navigate("main/main-page");
}

exports.onCancelButtonTap = onCancelButtonTap;